docker build -t ui_manager ./ui_manager
docker build -t model_manager ./model_manager
docker build -t app_service ./app_service
docker build -t scheduler ./scheduler
docker build -t deployer ./deployer
docker build -t sensor_manager ./sensor_manager
docker build -t control_manager ./control_manager
docker build -t node_manager ./node_manager

