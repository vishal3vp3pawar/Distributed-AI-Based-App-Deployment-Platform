# pip install -r requirements.txt
python3 ui_manager_app.py