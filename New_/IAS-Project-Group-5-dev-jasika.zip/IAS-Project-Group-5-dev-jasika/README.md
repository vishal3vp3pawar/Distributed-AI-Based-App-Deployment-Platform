# IAS-Project-Group-5

Pre-requisites:
1. Start Zookeeper and kafka server
   
Start the following services:
1. sensor manager
2. control manager
3. controllers
4. model service
5. app service
6. scheduler
7. deployer
   